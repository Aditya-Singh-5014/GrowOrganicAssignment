import React, { useState } from "react";
import { TextField, Button, Container, Typography } from "@mui/material";
import { saveUserToLocalStorage } from "../utils/localStorage";
import { useNavigate } from "react-router-dom";
import "./Form.css";

const Form: React.FC = () => {
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const user = { name, phoneNumber, email };
    saveUserToLocalStorage(user);
    navigate("/second");
  };

  return (
    <Container className="container">
      <Typography variant="h4" gutterBottom>
        User Information
      </Typography>
      <form onSubmit={handleSubmit} className="form">
        <TextField
          label="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          label="Phone Number"
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          label="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <Button
          type="submit"
          variant="contained"
          color="primary"
          className="submit-button"
        >
          Submit
        </Button>
      </form>
    </Container>
  );
};

export default Form;
