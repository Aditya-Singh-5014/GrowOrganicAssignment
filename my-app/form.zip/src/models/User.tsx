export interface User {
  name: string;
  phoneNumber: string;
  email: string;
}
